Project File : ChessByBird.csproj
Required Resolution : 1152 x 864 (Minimum)


