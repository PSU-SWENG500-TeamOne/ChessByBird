﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChessByBird.ImageClient
{
    public class ImageClient
    {
        //TODO: build callable methods for the image client

        /// <summary>
        /// Builds image for game state
        /// </summary>
        /// <param name="gameState">FEN Value of the current game state</param>
        /// <param name="playerCurrentTurn">Name for the player who's turn it now is</param>
        /// <param name="playerNowWaiting">Name for player who just went</param>
        /// <returns>asset path for the new image</returns>
        public static string processImage(string gameState, string playerCurrentTurn, string playerNowWaiting)
        {
            string imageLocation = "";

            return imageLocation;
        }

        
    }
}
